const connect_to_db = require('./db');

// GET NEWS BY ARTICLE ID HANDLER

const newsWithTalks = require('./news_with_talks');

module.exports.get_news_by_id = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log('Received event:', JSON.stringify(event, null, 2));

    // Recupera l'article_id dai parametri della richiesta
    const article_id = event.queryStringParameters && event.queryStringParameters.article_id;

    if (!article_id) {
        callback(null, {
            statusCode: 400,
            headers: { 'Content-Type': 'text/plain' },
            body: 'article_id is required.'
        });
        return;
    }

    connect_to_db().then(() => {
        console.log('=> get_news_by_id', article_id);
        newsWithTalks.findOne({ article_id: article_id })
            .then(news => {
                if (!news) {
                    callback(null, {
                        statusCode: 404,
                        body: JSON.stringify({ message: 'News not found' })
                    });
                } else {
                    callback(null, {
                        statusCode: 200,
                        body: JSON.stringify(news)
                    });
                }
            })
            .catch(err =>
                callback(null, {
                    statusCode: err.statusCode || 500,
                    headers: { 'Content-Type': 'text/plain' },
                    body: 'Could not fetch the news.'
                })
            );
    });
};
