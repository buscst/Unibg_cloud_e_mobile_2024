const mongoose = require('mongoose');

const related_videos_schema = new mongoose.Schema({
    _id: String,
    slug: String,
    speakers: String,
    title: String,
    url: String,
    description: String,
    duration: String,
    publishedAt: String
}, { _id: false });

const news_with_talks_schema = new mongoose.Schema({
    article_id: String,
    title: String,
    link: String,
    creator: [String],
    description: String,
    pubDate: String,
    source_id: String,
    source_priority: String,
    source_url: String,
    source_icon: String,
    language: String,
    country: [String],
    category: [String],
    talks: [{
        _id: String,
        url_image: String,
        slug: String,
        url: String,
        speakers: String,
        title: String,
        internalId: String,
        description: String,
        duration: String,
        publishedAt: String,
        tags: [String],
        related_videos: [related_videos_schema]
    }]
}, { collection: 'news_with_talks' });

module.exports = mongoose.model('news_with_talks', news_with_talks_schema);
