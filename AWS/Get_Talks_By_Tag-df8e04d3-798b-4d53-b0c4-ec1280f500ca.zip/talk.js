const mongoose = require('mongoose');

const talk_schema = new mongoose.Schema({
    _id: String,
    url_image: String,
    slug: String,
    url: String,
    speakers: String,
    title: String,
    internalId: String,
    description: String,
    duration: String,
    publishedAt: String,
    tags: [String],
}, { collection: 'tedx_data' });

module.exports = mongoose.model('talk', talk_schema);