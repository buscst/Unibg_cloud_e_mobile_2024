const connect_to_db = require('./db');

// GET NEWS BY ARTICLE ID HANDLER

const Talk = require('./talk');

module.exports.get_talk_by_id = (event, context, callback) => {
    context.callbackWaitsForEmptyEventLoop = false;
    console.log('Received event:', JSON.stringify(event, null, 2));

    // Recupera l'article_id dai parametri della richiesta
    const _id = event.queryStringParameters && event.queryStringParameters._id;

    if (!_id) {
        callback(null, {
            statusCode: 400,
            headers: { 'Content-Type': 'text/plain' },
            body: '_id is required.'
        });
        return;
    }

    connect_to_db().then(() => {
        console.log('=> get_talk_by_id',_id);
        Talk.findOne({ _id: _id })
            .then(news => {
                if (!news) {
                    callback(null, {
                        statusCode: 404,
                        body: JSON.stringify({ message: 'News not found' })
                    });
                } else {
                    callback(null, {
                        statusCode: 200,
                        body: JSON.stringify(news)
                    });
                }
            })
            .catch(err =>
                callback(null, {
                    statusCode: err.statusCode || 500,
                    headers: { 'Content-Type': 'text/plain' },
                    body: 'Could not fetch the news.'
                })
            );
    });
};
