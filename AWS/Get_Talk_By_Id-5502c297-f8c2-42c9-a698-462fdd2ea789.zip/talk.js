const mongoose = require('mongoose');

// Define the related_videos schema
const related_videos_schema = new mongoose.Schema({
    _id: String,
    slug: String,
    speakers: String,
    title: String,
    url: String,
    description: String,
    duration: String,
    publishedAt: String
});

// Define the main tedx_data schema
const tedx_data_schema = new mongoose.Schema({
    _id: String,
    url_image: String,
    slug: String,
    url: String,
    speakers: String,
    title: String,
    internalId: String,
    description: String,
    duration: String,
    publishedAt: String,
    tags: [String],
    related_videos: [related_videos_schema]
}, { collection: 'tedx_data' });

module.exports = mongoose.model('tedx_data', tedx_data_schema);